/* =============  DO NOT MODIFY ============>> */

var express = require('express');
var app = express();

app.use(express.json());

var monk = require('monk');
var db = monk('127.0.0.1:27017/lab5-db');

app.use(express.static('public'), function(req,res,next){	
    req.db = db;
    next();
})

function renderHTML(docs){
    var response = `
        <tr><th>Student UID</th>
        <th>Student Name</th>
        <th>Exam Name</th>
        <th>Score</th>
        <th>Update Score</th>
    ` 

    for (var i = 0; i < docs.length; i++){
        var doc = docs[i];
        var td = `
            <tr><td>${doc.uid}</td>
            <td>${doc.name}</td>
            <td>${doc.exam}</td>
            <td>${doc.score}</td>
            <td>
                <input id="new_score_${doc.uid}_${doc.exam}" type="text"> 
                <button onclick="updateScore('${doc.uid}', '${doc.exam}')">
                    Update
                </button>
            </td></tr>
        `
        response += td;
    }

    return response
}

app.get('/', (req, res) => {    
    res.sendFile( __dirname + "/public/" + "scores.html" );
});

/* <<============  DO NOT MODIFY ============= */


// step 4.3
app.get('/get_scores', (req, res) => {    
    





});


// step 5.2
app.get('/get_statistics', (req, res) => {    
    





});


// step 6.2
app.post('/update_score', (req, res) => {
    


    
    
    var new_score = parseInt(req.body.new_score);	
    if (isNaN(new_score) || new_score < 0 || new_score > 100) 
		res.send("Invalid Score!");
    else{
        




    }
});


// launch the server with port 8081
var server = app.listen(8081, () => {
	var host = server.address().address
	var port = server.address().port
	console.log("lab5 app listening at http://%s:%s", host, port)
});

