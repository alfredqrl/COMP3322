// step 4.1
function findAllDocs() {
    





    calStatistics();
}

// step 4.2
function findDocsByUID(){
    





}

// step 5.1
function calStatistics(){
    var statistics = document.getElementById("statistics");
    while (statistics.firstChild) {
        statistics.firstChild.remove()
    }





}

// step 6.1
function updateScore(uid, exam){
    var new_score = document.getElementById(`new_score_${uid}_${exam}`).value;
			
   



    
}

