/* =============  DO NOT MODIFY ============>> */

$(document).ready(function() {
    showAllCourses();
});

// store courses locally obtained from server
var courses_list = [];

// check whether input boxes are filled
function isInputFilled(){
    var checked = true;
    $('#update_form input').each(function(){
        if($(this).val() == "") 
			checked = false;
    });
    return checked;
}

/* <<=============  DO NOT MODIFY ============ */


// step 7.2
function showAllCourses(){
    var table_content = `
        <tr><th>Course Name</th>
        <th>Credit</th>
        <th>Semester</th>
        <th>Action</th>
    `

    





}

$("#course_table").on('click','.linkDelete', deleteCourse);

// step 8.2
function deleteCourse(event){
    event.preventDefault();
    
    




}


$("#submitCourse").on('click', addOrUpdateCourse);

function addOrUpdateCourse(event){
    event.preventDefault();

    if(isInputFilled()){
        var name = $("#inputName").val()
        var new_doc = {
            "name": name,
            "credit": $("#inputCredit").val(),
            "semester": $("#inputSemester").val(),
        }

		var names = courses_list.map(function(elem) { return elem.name; });
        var index = names.indexOf(name);
        if(index != -1){
            // step 9.2 course exists - do update
            






        }else{
            // step 10.2 course doesn't exist - add
            




            
        }
    }else alert("Please fill in all fields.")
}